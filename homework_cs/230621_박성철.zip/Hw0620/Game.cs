﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace homework_cs.Hw0620
{

    public class MyBuffer
    {
        string[] buffer;

        public static int _BUFFER_SIZE = 30;

        public bool isWork { private set; get; }

        private enum color
        {
            WHITE = 0, RED = 1, GREEN = 2, BLUE = 3, YELLOW = 4
        }

        public MyBuffer()
        {
            isWork = false;
            buffer = new string[_BUFFER_SIZE];
        }

        public void SetBuffer(string[] map)
        {
            buffer = map;
        }

        public void PrintBuffer()
        {
            if (isWork) { return; }
            if (buffer == null) { return; }

            isWork = true;

            for (int y = 0; y < buffer.Length; y++)
            {
                if (buffer[y] == null) { break; }

                Console.SetCursorPosition(0, y);
                string[] splitString = buffer[y].Split('.');

                for (int i = 0; i < splitString.Length; i++)
                {

                    if (i % 3 == 0)
                    {
                        Console.Write(splitString[i]);
                    }
                    else if (i % 3 == 1)
                    {
                        switch (int.Parse(splitString[i]))
                        {
                            case (int)color.WHITE:
                                Console.ForegroundColor = ConsoleColor.White;
                                break;
                            case (int)color.RED:
                                Console.ForegroundColor = ConsoleColor.Red;
                                break;
                            case (int)color.GREEN:
                                Console.ForegroundColor = ConsoleColor.Green;
                                break;
                            case (int)color.BLUE:
                                Console.ForegroundColor = ConsoleColor.Blue;
                                break;
                            case (int)color.YELLOW:
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                break;
                            default:
                                break;
                        }   //[switch] end 컬러체크
                    }
                    else if (i % 3 == 2)
                    {
                        Console.Write(splitString[i]);
                        Console.ForegroundColor = ConsoleColor.White;
                    }


                }// 1행 출력 종료

            }//모든 행 출력 종료
            Console.SetCursorPosition(0, 20);
            Console.Write(Utility.player.score);
            Console.SetCursorPosition(0, 21);

            isWork = false;
        }
    }

    public static class Utility
    {
        public static Random random = new Random();
        public static Room currRoom = default;
        public static Player player = default;
    }

    public class Player
    {
        public int X; public int Y;
        public bool isLive;
        public int score;

        int[] axisX = { 1, -1, 0, 0, 0 };
        int[] axisY = { 0, 0, -1, 1, 0 };

        public Player() { }
        public Player(int x, int y)
        {
            isLive = true;
            X = x;
            Y = y;
            score = 0;
        }

        public int GetNextX(int direction)
        {
            return X + axisX[direction];
        }

        public int GetNextY(int direction)
        {
            return Y + axisY[direction];
        }

        public void MoveAndHold(int direction, int XSize, int YSize)
        {
            X += axisX[direction];
            Y += axisY[direction];

            HoldX(XSize);
            HoldY(YSize);
        }

        public void MoveAndTeleport(int direction, int XSize, int YSize)
        {
            X += axisX[direction];
            Y += axisY[direction];

            Teleport(XSize, YSize);
        }

        public void HoldX(int XSize)
        {
            if (X < 0)
            {
                X = 0;
            }
            else if (X >= XSize)
            {
                X = XSize - 1;
            }

        }
        public void HoldY(int YSize)
        {
            if (Y < 0)
            {
                Y = 0;
            }
            else if (Y >= YSize)
            {
                Y = YSize - 1;
            }
        }

        public void HoldXY(ref int x, ref int y, int sizeX, int sizeY)
        {
            if (x < 0)
            {
                x = 0;
            }
            else if (x >= sizeX)
            {
                x = sizeX - 1;
            }
            if (y < 0)
            {
                y = 0;
            }
            else if (y >= sizeY)
            {
                y = sizeY - 1;
            }

        }
        public void Teleport(int XSize, int Ysize)
        {
            if (X == 0)
            {
                X = XSize - 1;
            }
            else if (X == XSize - 1)
            {
                X = 0;
            }
            else if (Y == 0)
            {
                Y = Ysize - 1;
            }
            else if (Y == Ysize - 1)
            {
                Y = 0;
            }
        }
    }


    public class Enemy
    {
        public Timer enemyTimer;
        public int X; public int Y;
        public bool isLive;
        public int randMoveCount;

        int[] axisX = { 1, -1, 0, 0, 0 };
        int[] axisY = { 0, 0, -1, 1, 0 };

        public Enemy(int x, int y)
        {
            X = x;
            Y = y;
            enemyTimer = new Timer(MoveTimer, null, 3000, 1000);
            isLive = false;
            randMoveCount = 0;

        }

        public void MoveTimer(object obj)
        {
            if (!isLive)
            {
                isLive = true;
            }

            Player player = Utility.player;
            int nextX = this.X;
            int nextY = this.Y;

            if (randMoveCount > 0)
            {
                nextX = this.X + axisX[Utility.random.Next(4)];
                nextY = this.Y + axisY[Utility.random.Next(4)];

                nextX = HoldX(nextX, Room.ROOM_SIZE);
                nextY = HoldY(nextY, Room.ROOM_SIZE);

                if (Utility.currRoom.GetElementAt(nextX, nextY) != 2 && Utility.currRoom.FindEnemiesAt(nextX, nextY) == null)
                {
                    this.X = nextX;
                    this.Y = nextY;
                }

                nextX = this.X + axisX[Utility.random.Next(4)];
                nextY = this.Y + axisY[Utility.random.Next(4)];

                nextX = HoldX(nextX, Room.ROOM_SIZE);
                nextY = HoldY(nextY, Room.ROOM_SIZE);

                if (Utility.currRoom.GetElementAt(nextX, nextY) != 2 && Utility.currRoom.FindEnemiesAt(nextX, nextY) == null)
                {
                    this.X = nextX;
                    this.Y = nextY;
                }

                randMoveCount -= 1;
            }

            if (Utility.random.Next(2) % 2 == 0)
            {
                if (player.X < this.X)
                {
                    nextX = this.X - 1;
                }
                else if (player.X > this.X)
                {
                    nextX = this.X + 1;
                }
                else
                {
                    if (player.Y < this.Y)
                    {
                        nextY = this.Y - 1;
                    }
                    else if (player.Y > this.Y)
                    {
                        nextY = this.Y + 1;
                    }
                }

                nextX = HoldX(nextX, Room.ROOM_SIZE);
                nextY = HoldY(nextY, Room.ROOM_SIZE);
            }
            else
            {
                if (player.Y < this.Y)
                {
                    nextY = this.Y - 1;
                }
                else if (player.Y > this.Y)
                {
                    nextY = this.Y + 1;
                }
                else
                {
                    if (player.X < this.X)
                    {
                        nextX = this.X - 1;
                    }
                    else if (player.X > this.X)
                    {
                        nextX = this.X + 1;
                    }
                }
                nextX = HoldX(nextX, Room.ROOM_SIZE);
                nextY = HoldY(nextY, Room.ROOM_SIZE);
            }

            if (Utility.currRoom.GetElementAt(nextX, nextY) != 2 && Utility.currRoom.FindEnemiesAt(nextX, nextY) == null)
            {
                this.X = nextX;
                this.Y = nextY;
            }
            else
            {
                randMoveCount += 2;
            }
            if (player.X == this.X && player.Y == this.Y)
            {
                player.isLive = false;
                enemyTimer.Dispose();

                return;
            }
        }

        public void HoldX(int XSize)
        {
            if (X < 0)
            {
                X = 0;
            }
            else if (X >= XSize)
            {
                X = XSize - 1;
            }

        }

        public int HoldX(int x, int XSize)
        {
            if (x < 0)
            {
                x = 0;
            }
            else if (x >= XSize)
            {
                x = XSize - 1;
            }
            return x;


        }
        public int HoldY(int y, int YSize)
        {
            if (y < 0)
            {
                y = 0;
            }
            else if (y >= YSize)
            {
                y = YSize - 1;
            }
            return y;
        }
        public void HoldY(int YSize)
        {
            if (Y < 0)
            {
                Y = 0;
            }
            else if (Y >= YSize)
            {
                Y = YSize - 1;
            }
        }
    }
    public class Game
    {
        string[] line;
        MyBuffer buffer;

        int currFieldX;
        int currFieldY;
        int direction;

        int[] axisX = { 1, -1, 0, 0, 0 };
        int[] axisY = { 0, 0, -1, 1, 0 };

        public Game()
        {
            line = new string[Room.ROOM_SIZE];
            buffer = new MyBuffer();
        }

        public void Start()
        {
            Console.CursorVisible = false;

            Map map = new Map(5);

            currFieldX = map.size / 2;
            currFieldY = map.size / 2;

            Utility.currRoom = map.field[currFieldY, currFieldX];
            Utility.currRoom.enemyTimer.Change(0, 10000);
            Utility.player = new Player(5, 5);

            direction = 5;
            bool isMove = false;
            bool isBreak = false;


            Timer printTimer = new Timer(PrintMap, line, 100, 100);


            while (true)
            {
                Console.SetCursorPosition(0, 21);

                isMove = false;
                isBreak = false;

                switch (Console.ReadKey(true).Key)
                {
                    case ConsoleKey.RightArrow:
                        isMove = true;
                        direction = 0;
                        break;
                    case ConsoleKey.LeftArrow:
                        isMove = true;
                        direction = 1;
                        break;
                    case ConsoleKey.UpArrow:
                        isMove = true;
                        direction = 2;
                        break;
                    case ConsoleKey.DownArrow:
                        isMove = true;
                        direction = 3;
                        break;
                    case ConsoleKey.Z:
                        isBreak = true;
                        break;
                    default:
                        direction = 4;
                        break;
                }

                //패배
                if (!Utility.player.isLive)
                {
                    PrintMap(line);
                    Console.SetCursorPosition(0, 24);
                    Console.WriteLine("패배");

                    printTimer.Dispose();
                    return;
                }

                //이동
                if (isMove)
                {
                    int beforeX = Utility.player.X;
                    int beforeY = Utility.player.Y;
                    Utility.player.MoveAndHold(direction, Room.ROOM_SIZE, Room.ROOM_SIZE);

                    int currX = Utility.player.X;
                    int currY = Utility.player.Y;


                    if (Utility.currRoom.roomInfomation[currY, currX] == 0 || Utility.currRoom.roomInfomation[currY, currX] == 1)
                    {
                        Utility.player.score += 1;
                    }

                    else if (Utility.currRoom.roomInfomation[currY, currX] == 2)
                    {
                        Utility.player.X = beforeX;
                        Utility.player.Y = beforeY;

                    }

                    else if (Utility.currRoom.roomInfomation[currY, currX] == 3)
                    {
                        for (int i = 0; i < 4; i++)
                        {
                            if (Utility.currRoom.portal[i] == null) { continue; }


                            if (currX == Utility.currRoom.portal[i].X && currY == Utility.currRoom.portal[i].Y)
                            {
                                switch (i)
                                {
                                    case 0:
                                        currFieldX += 1;
                                        break;
                                    case 1:
                                        currFieldX -= 1;

                                        break;
                                    case 2:
                                        currFieldY -= 1;

                                        break;
                                    case 3:
                                        currFieldY += 1;

                                        break;
                                }
                                Utility.player.Teleport(Room.ROOM_SIZE, Room.ROOM_SIZE);

                                Utility.currRoom.StopEnemies();
                                Utility.currRoom.enemyTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);

                                Utility.currRoom = map.field[currFieldY, currFieldX];
                                Utility.currRoom.PlayEnemies();
                                Utility.currRoom.enemyTimer.Change(0, 10000);

                                break;
                            }
                        }
                    }

                    Enemy tmp = Utility.currRoom.FindEnemiesAt(currX, currY);
                    if (tmp != null && tmp.isLive)
                    {
                        Console.SetCursorPosition(0, 24);
                        Console.WriteLine("패배");
                        PrintMap(line);

                        printTimer.Dispose();
                        return;
                        
                    }


                }//[if(isMove)] 종료

                //벽파괴
                if (isBreak)
                {
                    if (Utility.player.score > 10)
                    {
                        int nextX = Utility.player.GetNextX(direction);
                        int nextY = Utility.player.GetNextY(direction);

                        if (Utility.currRoom.roomInfomation[nextY, nextX] == 2)
                        {
                            Utility.player.HoldXY(ref nextX, ref nextY, Room.ROOM_SIZE, Room.ROOM_SIZE);
                            Utility.currRoom.roomInfomation[nextY, nextX] = 0;
                            Utility.player.score -= 10;
                        }

                    }
                }

            }

        }

        public void MapToStringArray(ref string[] line)
        {
            for (int y = 0; y < Room.ROOM_SIZE; y++)
            {
                line[y] = "";
                for (int x = 0; x < Room.ROOM_SIZE; x++)
                {
                    Enemy tmp = Utility.currRoom.FindEnemiesAt(x, y);
                    if (tmp != null)
                    {
                        if (tmp.isLive)
                        {
                            if (tmp.randMoveCount > 0)
                            {
                                line[y] += ".1.？.";
                            }
                            else
                            {
                                line[y] += ".1.적.";
                            }
                        }
                        else if (!tmp.isLive)
                        {
                            line[y] += ".3.봉.";
                        }
                        continue;
                    }

                    if (Utility.player.X == x && Utility.player.Y == y)
                    {
                        switch (direction)
                        {
                            case 0:
                                line[y] += ".4.▶.";
                                break;
                            case 1:
                                line[y] += ".4.◀.";
                                break;
                            case 2:
                                line[y] += ".4.▲.";
                                break;
                            case 3:
                                line[y] += ".4.▼.";
                                break;
                            default:
                                line[y] += ".4.나.";
                                break;
                        }
                    }
                    else
                    {
                        switch (Utility.currRoom.roomInfomation[y, x])
                        {
                            case 0:
                                line[y] += ".0.　.";
                                break;
                            case 1:
                                line[y] += ".0.＊.";
                                break;
                            case 2:
                                line[y] += ".0.〓.";
                                break;
                            case 3:
                                line[y] += ".2.문.";
                                break;
                        }
                    }
                }
            }

        }

        public void PrintMap(Object obj)
        {
            MapToStringArray(ref line);
            if (!buffer.isWork)
            {
                buffer.SetBuffer((string[])obj);
                buffer.PrintBuffer();
            }

            else
            {
                Console.Clear();
            }
        }

    }
    /// <summary>
    /// 맵
    /// </summary>
    /// <return>함수가 정상작동시 true</return>
    public class Map
    {
        int[] axisX = { 1, -1, 0, 0 };
        int[] axisY = { 0, 0, -1, 1 };
        public Room[,] field;
        public int size;


        public Map() { }
        public Map(int size)
        {
            this.size = size;
            field = new Room[size, size];

            for (int y = 0; y < field.GetLength(0); y++)
            {
                for (int x = 0; x < field.GetLength(1); x++)
                {

                    //홀수 행, 짝수 열
                    if (y % 2 == 0 && x % 2 == 1)
                    {
                        field[y, x] = new Room(Utility.random.Next(0, 16));

                        if (x == 0 && field[y, x].portal[1] != null)
                        {
                            Door currPortal = field[y, x].portal[1];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[1] = null;
                        }
                        if (x == size - 1 && field[y, x].portal[0] != null)
                        {
                            Door currPortal = field[y, x].portal[0];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[0] = null;
                        }
                        if (y == size - 1 && field[y, x].portal[3] != null)
                        {
                            Door currPortal = field[y, x].portal[3];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[3] = null;
                        }
                        if (y == 0 && field[y, x].portal[2] != null)
                        {
                            Door currPortal = field[y, x].portal[2];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[2] = null;
                        }
                    }
                    else if (y % 2 == 1 && x % 2 == 0)
                    {

                        field[y, x] = new Room(Utility.random.Next(0, 16));
                        if (x == 0 && field[y, x].portal[1] != null)
                        {
                            Door currPortal = field[y, x].portal[1];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[1] = null;
                        }
                        if (x == size - 1 && field[y, x].portal[0] != null)
                        {
                            Door currPortal = field[y, x].portal[0];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[0] = null;
                        }
                        if (y == size - 1 && field[y, x].portal[3] != null)
                        {
                            Door currPortal = field[y, x].portal[3];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[3] = null;
                        }
                        if (y == 0 && field[y, x].portal[2] != null)
                        {
                            Door currPortal = field[y, x].portal[2];
                            field[y, x].roomInfomation[currPortal.Y, currPortal.X] = 0;
                            field[y, x].portal[2] = null;
                        }
                    }

                }

            }

            for (int y = 0; y < field.GetLength(0); y++)
            {
                for (int x = 0; x < field.GetLength(1); x++)
                {
                    //홀수 행, 짝수 열
                    if ((y % 2 == 0 && x % 2 == 0) || (y % 2 == 1 && x % 2 == 1))
                    {
                        field[y, x] = new Room();
                        if (x != 0 && field[y, x - 1].portal[0] != null)
                        {
                            Door nextDoor = field[y, x - 1].portal[0];

                            field[y, x].portal[1] = new Door(0, nextDoor.Y);
                            Door currDoor = field[y, x].portal[1];


                            field[y, x].roomInfomation[currDoor.Y, currDoor.X] = 3;

                        }

                        if (x != size - 1 && field[y, x + 1].portal[1] != null)
                        {
                            Door nextDoor = field[y, x + 1].portal[1];

                            field[y, x].portal[0] = new Door(Room.ROOM_SIZE - 1, nextDoor.Y);
                            Door currDoor = field[y, x].portal[0];

                            field[y, x].roomInfomation[currDoor.Y, currDoor.X] = 3;


                        }

                        if (y != size - 1 && field[y + 1, x].portal[2] != null)
                        {
                            Door nextDoor = field[y + 1, x].portal[2];

                            field[y, x].portal[3] = new Door(nextDoor.X, Room.ROOM_SIZE - 1);
                            Door currDoor = field[y, x].portal[3];

                            field[y, x].roomInfomation[currDoor.Y, currDoor.X] = 3;

                        }

                        if (y != 0 && field[y - 1, x].portal[3] != null)
                        {
                            Door nextDoor = field[y - 1, x].portal[3];

                            field[y, x].portal[2] = new Door(nextDoor.X, 0);
                            Door currDoor = field[y, x].portal[2];

                            field[y, x].roomInfomation[currDoor.Y, currDoor.X] = 3;

                        }
                    }

                }

            }
        }

    }

    public class Room
    {
        int[] axisX = { 1, -1, 0, 0 };
        int[] axisY = { 0, 0, -1, 1 };

        int x; int y;

        public List<Enemy> enemies;
        public Timer enemyTimer;

        public int[,] roomInfomation;
        public static int ROOM_SIZE = 15;

        public void CreateEnemy(object obj)
        {
            if (enemies.Count > 6) return;
            while (true)
            {
                int enemyX = Utility.random.Next(ROOM_SIZE);
                int enemyY = Utility.random.Next(ROOM_SIZE);
                if (roomInfomation[enemyY, enemyX] != 2)
                {
                    Enemy e = new Enemy(enemyX, enemyY);
                    enemies.Add(e);
                    break;
                }
            }
        }

        //{동,서,북,남}
        public Door[] portal;

        public Room()
        {
            enemyTimer = new Timer(CreateEnemy, null, System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);

            int wallCount = 60;
            int wallSleep = 2;
            roomInfomation = new int[ROOM_SIZE, ROOM_SIZE];
            for (int y = 0; y < ROOM_SIZE; y++)
            {
                for (int x = 0; x < ROOM_SIZE; x++)
                {
                    if (wallSleep == 0 && wallCount > 0)
                    {
                        roomInfomation[y, x] = Utility.random.Next(3);
                        if (roomInfomation[y, x] == 2)
                        {
                            wallCount -= 1;
                            wallSleep = 3;
                        }
                    }
                    else if (wallSleep > 0 || wallCount == 0)
                    {
                        roomInfomation[y, x] = Utility.random.Next(2);
                        wallSleep -= 1;
                    }
                }
            }
            enemies = new List<Enemy>();
            portal = new Door[4];
        }
        public Room(int flag)
        {
            enemyTimer = new Timer(CreateEnemy, null, System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            int wallCount = 60;
            int wallSleep = 2;
            roomInfomation = new int[ROOM_SIZE, ROOM_SIZE];
            for (int y = 0; y < ROOM_SIZE; y++)
            {
                for (int x = 0; x < ROOM_SIZE; x++)
                {
                    if (wallSleep == 0 && wallCount > 0)
                    {
                        roomInfomation[y, x] = Utility.random.Next(3);
                        if (roomInfomation[y, x] == 2)
                        {
                            wallCount -= 1;
                            wallSleep = 3;
                        }
                    }
                    else if (wallSleep > 0 || wallCount == 0)
                    {
                        roomInfomation[y, x] = Utility.random.Next(2);
                        wallSleep -= 1;
                    }
                }
            }

            enemies = new List<Enemy>();
            portal = new Door[4];
            int bit = 1;

            for (int i = 0; i < portal.Length; i++)
            {
                if ((flag & bit) == bit)
                {
                    switch (i)
                    {
                        case 0:
                            portal[i] = new Door(ROOM_SIZE - 1, Utility.random.Next(1, ROOM_SIZE - 1));
                            break;
                        case 1:
                            portal[i] = new Door(0, Utility.random.Next(1, ROOM_SIZE - 1));
                            break;
                        case 2:
                            portal[i] = new Door(Utility.random.Next(1, ROOM_SIZE - 1), 0);
                            break;
                        case 3:
                            portal[i] = new Door(Utility.random.Next(1, ROOM_SIZE - 1), ROOM_SIZE - 1);
                            break;
                    }
                    roomInfomation[portal[i].Y, portal[i].X] = 3;
                }
                else
                {
                    portal[i] = null;
                }
                bit = bit << 1;
            }

            //portal[0].asd();
        }

        public int GetElementAt(int x, int y)
        {
            return roomInfomation[y, x];
        }
        public Enemy FindEnemiesAt(int x, int y)
        {
            for (int i = 0; i < enemies.Count; i++)
            {
                if (enemies[i] == null) continue;
                if (enemies[i].X == x && enemies[i].Y == y) return enemies[i];
            }
            return null;
        }
        public void StopEnemies()
        {
            for (int i = 0; i < enemies.Count; i++)
            {
                enemies[i].enemyTimer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            }
            return;
        }
        public void PlayEnemies()
        {
            for (int i = 0; i < enemies.Count; i++)
            {
                enemies[i].enemyTimer.Change(500, 500);
            }
        }
    }

    public class Door
    {
        public int X;
        public int Y;

        public Door()
        {
        }

        public Door(int x, int y)
        {
            this.X = x;
            this.Y = y;
        }

    }

}
